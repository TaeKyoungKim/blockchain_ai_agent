<#
.SYNOPSIS
    Starts a local Geth private network in developer mode (--dev) for Phase 1 testing.
.DESCRIPTION
    Runs Geth with HTTP JSON-RPC enabled on 127.0.0.1:8545, PoA/instant-sealing dev mode,
    and exposes required APIs (eth, net, web3, personal, txpool).
#>

[CmdletBinding()]
param (
    [string]$DataDir = "$PSScriptRoot\..\.geth_dev_data",
    [string]$RpcPort = "8545",
    [string]$NetworkId = "1337"
)

if (-not (Get-Command geth -ErrorAction SilentlyContinue)) {
    Write-Error "Geth (Go-Ethereum) executable is not found in PATH. Please install Geth or ensure geth.exe is accessible."
    exit 1
}

if (-not (Test-Path $DataDir)) {
    New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
    Write-Host "[Geth] Created data directory: $DataDir" -ForegroundColor Cyan
}

Write-Host "[Geth] Starting private dev network on http://127.0.0.1:$RpcPort..." -ForegroundColor Green
Write-Host "[Geth] Data directory: $DataDir" -ForegroundColor Gray
Write-Host "[Geth] Network ID: $NetworkId" -ForegroundColor Gray

& geth --datadir $DataDir `
  --dev `
  --dev.period 0 `
  --http `
  --http.addr "127.0.0.1" `
  --http.port $RpcPort `
  --http.corsdomain "*" `
  --http.api "eth,net,web3,personal,txpool" `
  --networkid $NetworkId

